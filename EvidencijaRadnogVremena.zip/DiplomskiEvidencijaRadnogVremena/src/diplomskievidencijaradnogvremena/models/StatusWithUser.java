
package diplomskievidencijaradnogvremena.models;

import diplomskievidencijaradnogvremena.DB;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;


public class StatusWithUser {
    private Status status;
    private User user;
    
    public StatusWithUser() {
        this.status = null;
        this.user = null;
    }

    public StatusWithUser(Status status, User user) {
        this.status = status;
        this.user = user;
    }
    
    
    
    public static StatusWithUser resultSetToStatusWithUser(ResultSet rs){
        StatusWithUser statusWithUser = new StatusWithUser();
        try {
            Status status = new Status(0, rs.getString("Naziv"), rs.getLong("UserID"), rs.getTimestamp("Vrijeme"));
            status.setID(rs.getLong("ID"));
            
            User user = new User(rs.getString("Username"), rs.getString("Password"), rs.getString("Role"));
            user.setID(rs.getLong("UserID"));
            
            statusWithUser.setStatus(status);
            statusWithUser.setUser(user);
        } catch (SQLException ex) {
            Logger.getLogger(Status.class.getName()).log(Level.SEVERE, null, ex);
        }
        return statusWithUser;
    }
    
    
    public static ArrayList<StatusWithUser> getAll(){
        ArrayList<StatusWithUser> statusWithUser = new ArrayList<>();
        List<Object> params = Arrays.asList();
        DB db = new DB();
        db.select("SELECT s.ID, s.Naziv, s.Vrijeme, s.UserID, u.Username, u.Password, u.Role FROM statusi s, users u WHERE s.UserID=u.ID ORDER BY s.Vrijeme DESC", params);
        
        try {
            while(db.getResultSet().next()){
                statusWithUser.add(resultSetToStatusWithUser(db.getResultSet()));
            }
        } catch (SQLException ex) {
            Logger.getLogger(Status.class.getName()).log(Level.SEVERE, null, ex);
        }
        db.disconnect();
        return statusWithUser;
    }
    
    public static ArrayList<StatusWithUser> getAllForUser(long UserID){
        ArrayList<StatusWithUser> status = new ArrayList<>();
        List<Object> params = Arrays.asList(UserID);
        DB db = new DB();
        db.select("SELECT s.ID, s.Naziv, s.Vrijeme, s.UserID, u.Username, u.Password, u.Role  \n" +
                    "FROM statusi s, users u\n" +
                    "WHERE \n" +
                    "s.UserID=u.ID AND\n" +
                    "s.UserID=?\n" +
                    "ORDER BY s.Vrijeme DESC", params);
        
        try {
            while(db.getResultSet().next()){
                status.add(resultSetToStatusWithUser(db.getResultSet()));
            }
        } catch (SQLException ex) {
            Logger.getLogger(Status.class.getName()).log(Level.SEVERE, null, ex);
        }
        db.disconnect();
        return status;
    }
    
    
    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }
    
    
    public String getUsername(){
        return this.user != null ? this.user.getUsername() : "";
    }
    
    public String getStatusNaziv(){
        return this.status != null ? this.status.getNaziv() : "";
    }
    
    public String getVrijeme(){
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
        String string  = dateFormat.format(this.status.getVrijeme());
        return this.status != null ? string : "";
    }
}
