/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package diplomskievidencijaradnogvremena.controllers;

import diplomskievidencijaradnogvremena.models.StatusWithUser;
import diplomskievidencijaradnogvremena.services.LoginService;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

/**
 * FXML Controller class
 *
 * @author owner
 */
public class AdminPregledRadnihVremenaController implements Initializable {
    @FXML
    TextField txtSearch;
    
    @FXML
    Button btnIzmjeni, btnBrisi, btnDodaj, btnEvidencija, btnKorisnici, btnPostavke, btnLogout;
    
    @FXML
    TableView<StatusWithUser> tblStatusi;
    
    @FXML
    TableColumn<StatusWithUser, String> tblColStatus,tblColUsername, tblColVrijeme;
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        ArrayList<StatusWithUser> statusi = StatusWithUser.getAll();
        ObservableList<StatusWithUser> data = FXCollections.observableArrayList(statusi);
        //tblColRN.setCellValueFactory(new PropertyValueFactory<User, String>("Naziv"));
        tblColStatus.setCellValueFactory(new PropertyValueFactory<StatusWithUser, String>("StatusNaziv"));
        tblColUsername.setCellValueFactory(new PropertyValueFactory<StatusWithUser, String>("Username"));
        tblColVrijeme.setCellValueFactory(new PropertyValueFactory<StatusWithUser, String>("Vrijeme"));
        tblStatusi.setItems(data);
    }   
    
    public void btnEvidencijaOnClick(){
        
    }
    public void btnKorisniciOnClick(){
       diplomskievidencijaradnogvremena.DiplomskiEvidencijaRadnogVremena.openWindow("Pregled korisnika", btnKorisnici.getParent(), "AdminPregledKorisnika");
    }
    public void btnPostavkeOnClick(){
        diplomskievidencijaradnogvremena.DiplomskiEvidencijaRadnogVremena.openWindow("Postavke", btnKorisnici.getParent(), "UserProfil");
    }
    public void btnLogoutOnClick(){
        LoginService.logout(btnKorisnici.getParent());
    }
    
    
    public  void btnIzmjeniOnClick() {
        
    } 
    public void btnBrisiOnClick(){/*
        StatusWithUser statusWithUser = tblStatusi.getSelectionModel().getSelectedItem();
        if(statusWithUser != null){
            tblStatusi.setItems(FXCollections.observableArrayList(StatusWithUser.getAll()));
        }*/
    }
    public void btnDodajOnClick() {
        
    } 

    
    
}
