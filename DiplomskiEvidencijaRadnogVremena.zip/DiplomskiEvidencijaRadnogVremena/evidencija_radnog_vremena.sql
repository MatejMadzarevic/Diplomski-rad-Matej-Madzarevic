-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 06, 2020 at 09:44 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `evidencija_radnog_vremena`
--

-- --------------------------------------------------------

--
-- Table structure for table `statusi`
--

CREATE TABLE `statusi` (
  `ID` int(11) NOT NULL,
  `Naziv` varchar(255) COLLATE utf8_bin NOT NULL,
  `UserID` int(11) NOT NULL,
  `Vrijeme` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `statusi`
--

INSERT INTO `statusi` (`ID`, `Naziv`, `UserID`, `Vrijeme`) VALUES
(1, 'DOLAZAK', 2, '2020-03-04 19:33:10'),
(2, 'PAUZA', 2, '2020-03-04 19:33:24'),
(3, 'KRAJ PAUZE', 2, '2020-03-05 15:09:24'),
(4, 'ODLAZAK', 2, '2020-03-05 15:10:09'),
(5, 'DOLAZAK', 2, '2020-03-05 15:10:12'),
(6, 'PAUZA', 2, '2020-03-05 15:10:13'),
(7, 'KRAJ PAUZE', 2, '2020-03-05 15:10:14'),
(8, 'PAUZA', 2, '2020-03-05 15:10:19'),
(9, 'KRAJ PAUZE', 2, '2020-03-05 15:10:20'),
(10, 'ODLAZAK', 2, '2020-03-05 15:10:21'),
(11, 'DOLAZAK', 2, '2020-03-05 15:15:20'),
(12, 'PAUZA', 2, '2020-03-05 15:15:26'),
(13, 'KRAJ PAUZE', 2, '2020-03-05 15:17:16'),
(14, 'ODLAZAK', 2, '2020-03-05 15:17:19'),
(15, 'DOLAZAK', 2, '2020-03-05 15:17:20'),
(16, 'PAUZA', 2, '2020-03-05 15:17:21'),
(17, 'KRAJ PAUZE', 2, '2020-03-05 15:17:22'),
(18, 'PAUZA', 2, '2020-03-05 15:17:23'),
(19, 'KRAJ PAUZE', 2, '2020-03-05 15:17:24'),
(20, 'ODLAZAK', 2, '2020-03-05 15:17:24'),
(21, 'ODLAZAK', 2, '2020-03-06 20:41:54'),
(22, 'DOLAZAK', 2, '2020-03-06 20:41:55'),
(23, 'PAUZA', 2, '2020-03-06 20:41:56'),
(24, 'KRAJ PAUZE', 2, '2020-03-06 20:41:57'),
(25, 'ODLAZAK', 2, '2020-03-06 20:41:57'),
(26, 'DOLAZAK', 2, '2020-03-06 20:42:05'),
(27, 'PAUZA', 2, '2020-03-06 20:42:12');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `ID` int(11) NOT NULL,
  `Username` varchar(255) COLLATE utf8_bin NOT NULL,
  `Password` varchar(255) COLLATE utf8_bin NOT NULL,
  `Role` varchar(255) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`ID`, `Username`, `Password`, `Role`) VALUES
(1, 'admin', 'asd', 'admin'),
(2, 'user', 'asd', 'user'),
(5, 'user2', 'asd', 'user');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `statusi`
--
ALTER TABLE `statusi`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `user_id_fk` (`UserID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `statusi`
--
ALTER TABLE `statusi`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `statusi`
--
ALTER TABLE `statusi`
  ADD CONSTRAINT `user_id_fk` FOREIGN KEY (`UserID`) REFERENCES `users` (`ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
