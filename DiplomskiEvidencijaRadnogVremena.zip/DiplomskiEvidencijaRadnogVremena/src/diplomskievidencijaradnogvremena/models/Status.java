
package diplomskievidencijaradnogvremena.models;

import diplomskievidencijaradnogvremena.DB;
import static diplomskievidencijaradnogvremena.models.User.resultSetToUser;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Status {
    private long ID;
    private String Naziv;
    private long UserID;
    private Timestamp Vrijeme;

    public Status() {
        this.ID = 0;
        this.Naziv = "";
        this.UserID = 0;
        this.Vrijeme = Timestamp.from(Instant.now());
    }

    public Status(int ID, String Naziv, long UserID, Timestamp time) {
        this.ID = ID;
        this.Naziv = Naziv;
        this.UserID = UserID;
        this.Vrijeme = time;
    }
    
     
    public static Status resultSetToStatus(ResultSet rs){
        Status status = null;
        try {
            status = new Status(0, rs.getString("Naziv"), rs.getLong("UserID"), rs.getTimestamp("Vrijeme"));
            status.setID(rs.getLong("ID"));
        } catch (SQLException ex) {
            Logger.getLogger(Status.class.getName()).log(Level.SEVERE, null, ex);
        }
        return status;
    }
    
    
    public static ArrayList<Status> getAll(){
        ArrayList<Status> status = new ArrayList<>();
        List<Object> params = Arrays.asList();
        DB db = new DB();
        db.select("SELECT * FROM statusi", params);
        
        try {
            while(db.getResultSet().next()){
                status.add(resultSetToStatus(db.getResultSet()));
            }
        } catch (SQLException ex) {
            Logger.getLogger(Status.class.getName()).log(Level.SEVERE, null, ex);
        }
        db.disconnect();
        return status;
    }
    
    public static ArrayList<Status> getAllForUser(long UserID){
        ArrayList<Status> status = new ArrayList<>();
        List<Object> params = Arrays.asList(UserID);
        DB db = new DB();
        db.select("SELECT * FROM statusi WHERE UserID=? ORDER BY Time DESC", params);
        
        try {
            while(db.getResultSet().next()){
                status.add(resultSetToStatus(db.getResultSet()));
            }
        } catch (SQLException ex) {
            Logger.getLogger(Status.class.getName()).log(Level.SEVERE, null, ex);
        }
        db.disconnect();
        return status;
    }
    
    
    
    public static Status getUserCurrentStatus(long UserID){
        Status status = null;
        DB db = new DB();
        List<Object> params = Arrays.asList(UserID);
        db.select("SELECT * FROM statusi WHERE UserID=? ORDER BY Vrijeme DESC LIMIT 1", params);
        try {
            while(db.getResultSet().next()){
                status = resultSetToStatus(db.getResultSet());
            }
        } catch (SQLException ex) {
            Logger.getLogger(Status.class.getName()).log(Level.SEVERE, null, ex);
        }
        db.disconnect();
        return status;
    }


    public void delete(){
        DB db = new DB();
        List<Object> params = Arrays.asList(this.ID);        //db.delete("DELETE FROM kolegij WHERE PredavacID=?", params);
        db.delete("DELETE FROM statusi WHERE ID=?", params);
        db.disconnect();
    }
    
    public void insert(){
        DB db = new DB();
        List<Object> params = Arrays.asList(this.Naziv, this.UserID, this.Vrijeme);
        db.insert("INSERT INTO statusi(Naziv, UserID, Vrijeme) VALUES(?,?,?)", params);
        db.disconnect();
    }
    
    public void update(){
        DB db = new DB();
        List<Object> params = Arrays.asList(this.Naziv, this.UserID, this.Vrijeme, this.ID);
        db.update("UPDATE statusi SET Naziv=?, UserID=?, Vrijeme=? WHERE ID=?", params);
        db.disconnect();
    }
    
    

    public long getID() {
        return ID;
    }

    public void setID(long ID) {
        this.ID = ID;
    }

    public long getUserID() {
        return UserID;
    }

    public void setUserID(long UserID) {
        this.UserID = UserID;
    }
    
    
    
    
    

    public String getNaziv() {
        return Naziv;
    }

    public void setNaziv(String Naziv) {
        this.Naziv = Naziv;
    }

    public Timestamp getVrijeme() {
        return Vrijeme;
    }

    public void setVrijeme(Timestamp Vrijeme) {
        this.Vrijeme = Vrijeme;
    }

    
    
}
