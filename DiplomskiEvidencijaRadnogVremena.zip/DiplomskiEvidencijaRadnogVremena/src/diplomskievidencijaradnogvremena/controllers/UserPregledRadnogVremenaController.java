/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package diplomskievidencijaradnogvremena.controllers;

import diplomskievidencijaradnogvremena.models.StatusWithUser;
import diplomskievidencijaradnogvremena.services.LoginService;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

/**
 * FXML Controller class
 *
 * @author owner
 */
public class UserPregledRadnogVremenaController implements Initializable {

     @FXML
    Button btnIzmjeni, btnBrisi, btnDodaj, btnNazad, btnLogout, btnEvidencija, btnKorisnici, btnPostavke;
    
    @FXML
    TableView<StatusWithUser> tblStatusi;
    
    @FXML
    TableColumn<StatusWithUser, String> tblColStatus, tblColVrijeme;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        ArrayList<StatusWithUser> statusi = StatusWithUser.getAllForUser(LoginService.getUser().getID());
        ObservableList<StatusWithUser> data = FXCollections.observableArrayList(statusi);
        //tblColRN.setCellValueFactory(new PropertyValueFactory<User, String>("Naziv"));
        tblColStatus.setCellValueFactory(new PropertyValueFactory<StatusWithUser, String>("StatusNaziv"));
        tblColVrijeme.setCellValueFactory(new PropertyValueFactory<StatusWithUser, String>("Vrijeme"));
        tblStatusi.setItems(data);
    }    
    
    
    public void btnEvidencijaOnClick(){
        diplomskievidencijaradnogvremena.DiplomskiEvidencijaRadnogVremena.openWindow("Evidencija radnog vremena", btnLogout.getParent(), "UserPregledRadnogVremena");
    }
    public void btnKorisniciOnClick(){
       diplomskievidencijaradnogvremena.DiplomskiEvidencijaRadnogVremena.openWindow("Početna", btnLogout.getParent(), "UserDashboard");
    }
    public void btnPostavkeOnClick(){
        diplomskievidencijaradnogvremena.DiplomskiEvidencijaRadnogVremena.openWindow("Postavke", btnLogout.getParent(), "UserProfil");
    }
    public void btnLogoutOnClick(){
        LoginService.logout(btnLogout.getParent());
    }
    
     
    public  void btnIzmjeniOnClick() {
        
    } 
    public void btnBrisiOnClick(){/*
        StatusWithUser statusWithUser = tblStatusi.getSelectionModel().getSelectedItem();
        if(statusWithUser != null){
            tblStatusi.setItems(FXCollections.observableArrayList(StatusWithUser.getAll()));
        }*/
    }
    public void btnDodajOnClick() {
        
    } 
  
}
