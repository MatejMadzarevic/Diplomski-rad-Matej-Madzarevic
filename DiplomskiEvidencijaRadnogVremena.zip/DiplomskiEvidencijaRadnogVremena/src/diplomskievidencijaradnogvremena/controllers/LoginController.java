
package diplomskievidencijaradnogvremena.controllers;

import diplomskievidencijaradnogvremena.models.User;
import diplomskievidencijaradnogvremena.services.LoginService;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class LoginController implements Initializable {

    @FXML
    Button btnLogin;
    
    @FXML
    TextField txtUsername;
    
    @FXML
    PasswordField txtPassword;
    
    @FXML
    Label lblErrorMsg;
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        txtUsername.setText("admin");
        txtPassword.setText("asd");
        
    }    
    
    
    
    public void btnLoginOnAction() {
    
        String username = String.valueOf(txtUsername.getText());
        String password = String.valueOf(txtPassword.getText());
        
        if(!username.equals("")){
            if(!password.equals("")){
                User user = User.login(username, password);
                
                if(user != null){
                    LoginService.setUser(user);
                    System.out.println(user.getRole());
                    if(user.getRole().equals("admin")){
                        diplomskievidencijaradnogvremena.DiplomskiEvidencijaRadnogVremena.openWindow("Admin - Pregled radnih vremena", txtUsername.getParent(), "AdminPregledRadnihVremena");
                    }
                    else if(user.getRole().equals("user")){
                        diplomskievidencijaradnogvremena.DiplomskiEvidencijaRadnogVremena.openWindow("User - Dashboard", txtUsername.getParent(), "UserDashboard");
                    }
                }
                else{
                    lblErrorMsg.setText("Greška prilikom logiranja!");
                }
            }
            else{
                lblErrorMsg.setText("Unesite lozinku!");
            }
        }
        else{
            lblErrorMsg.setText("Unesite korisničko ime!");
        }
    }
    
    
    public void openWindow(String title, Parent mainWindow, String path){
    }
    
}
