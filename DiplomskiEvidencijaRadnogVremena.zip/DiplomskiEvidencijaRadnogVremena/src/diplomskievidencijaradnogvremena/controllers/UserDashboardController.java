/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package diplomskievidencijaradnogvremena.controllers;

import diplomskievidencijaradnogvremena.models.Status;
import diplomskievidencijaradnogvremena.services.LoginService;
import java.net.URL;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;

/**
 * FXML Controller class
 *
 * @author owner
 */
public class UserDashboardController implements Initializable {
  public long UserID = LoginService.getUser().getID();
    public Status currentStatus = Status.getUserCurrentStatus(UserID);
    
    @FXML
    Button btnLogout, btnEvidencija, btnKorisnici, btnPostavke;
    
    @FXML
    Button btnPregledRadnogVremena;
    
    @FXML
    Button btnProfil;
    
    @FXML
    Button btnDolazak;
    
    @FXML
    Button btnPauza;
    
    @FXML
    Button btnKrajPauze;
    
    @FXML
    Button btnOdlazak;
    
    @FXML
    Label lblTrenutniStatus;

    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        setButtonStates(currentStatus);
    }    
    
    
    
    
    public void btnEvidencijaOnClick(){
        diplomskievidencijaradnogvremena.DiplomskiEvidencijaRadnogVremena.openWindow("Evidencija radnog vremena", btnLogout.getParent(), "UserPregledRadnogVremena");
    }
    public void btnKorisniciOnClick(){
       diplomskievidencijaradnogvremena.DiplomskiEvidencijaRadnogVremena.openWindow("Početna", btnLogout.getParent(), "UserDashboard");
    }
    public void btnPostavkeOnClick(){
        diplomskievidencijaradnogvremena.DiplomskiEvidencijaRadnogVremena.openWindow("Postavke", btnLogout.getParent(), "UserProfil");
    }
    public void btnLogoutOnClick(){
        LoginService.logout(btnLogout.getParent());
    }
    
    public  void btnPregledRadnogVremenaOnAction() {
        diplomskievidencijaradnogvremena.DiplomskiEvidencijaRadnogVremena.openWindow("Pregled radnog vremena", btnDolazak.getParent(), "UserPregledRadnogVremena");
    }
    
    public  void btnProfilOnAction() {
        diplomskievidencijaradnogvremena.DiplomskiEvidencijaRadnogVremena.openWindow("Korisnički profil", btnDolazak.getParent(), "UserProfil");
    }
    
    public  void btnDolazakOnAction() {
        Status status = new Status(0, "DOLAZAK", UserID, Timestamp.from(Instant.now()));
        status.insert();
        currentStatus = status;
        setButtonStates(status);
    }
    
    public  void btnPauzaOnAction() {
        Status status = new Status(0, "PAUZA", UserID, Timestamp.from(Instant.now()));
        status.insert();
        currentStatus = status;
        setButtonStates(status);
    }
    
    public  void btnKrajPauzeOnAction() {
        Status status = new Status(0, "KRAJ PAUZE", UserID, Timestamp.from(Instant.now()));
        status.insert();
        currentStatus = status;
        setButtonStates(status);
    }
    
    public  void btnOdlazakOnAction() {
        Status status = new Status(0, "ODLAZAK", UserID, Timestamp.from(Instant.now()));
        status.insert();
        currentStatus = status;
        setButtonStates(status);
    }
    
    
    public void setButtonStates(Status status) {
        if(status != null){
            if(status.getNaziv().equals("DOLAZAK")){
                lblTrenutniStatus.setText(String.valueOf("Trenutni status: NA POSLU..."));
                btnDolazak.setDisable(true);
                btnOdlazak.setDisable(false);
                btnPauza.setDisable(false);
                btnKrajPauze.setDisable(true);
            }
            else if(status.getNaziv().equals("ODLAZAK")){
                lblTrenutniStatus.setText(String.valueOf("Trenutni status: ZAVRŠENO RADNO VRIJEME..."));
                btnDolazak.setDisable(false);
                btnOdlazak.setDisable(true);
                btnPauza.setDisable(true);
                btnKrajPauze.setDisable(true);
            }
            else if(status.getNaziv().equals("PAUZA")){
                lblTrenutniStatus.setText(String.valueOf("Trenutni status: NA PAUZI..."));
                btnDolazak.setDisable(true);
                btnOdlazak.setDisable(true);
                btnPauza.setDisable(true);
                btnKrajPauze.setDisable(false);
            }
            else if(status.getNaziv().equals("KRAJ PAUZE")){
                lblTrenutniStatus.setText(String.valueOf("Trenutni status: NA POSLU..."));
                btnDolazak.setDisable(true);
                btnOdlazak.setDisable(false);
                btnPauza.setDisable(false);
                btnKrajPauze.setDisable(true);
            }
        }
        else{
            lblTrenutniStatus.setText(String.valueOf("Trenutni status: ZAVRŠENO RADNO VRIJEME..."));
            btnDolazak.setDisable(false);
            btnOdlazak.setDisable(true);
            btnPauza.setDisable(true);
            btnKrajPauze.setDisable(true);
        }
    }  
    
}
