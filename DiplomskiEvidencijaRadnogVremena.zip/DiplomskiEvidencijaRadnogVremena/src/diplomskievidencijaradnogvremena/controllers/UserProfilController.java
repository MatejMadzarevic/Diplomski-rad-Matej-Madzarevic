
package diplomskievidencijaradnogvremena.controllers;

import diplomskievidencijaradnogvremena.models.User;
import diplomskievidencijaradnogvremena.services.LoginService;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.paint.Color;


public class UserProfilController implements Initializable {


    @FXML
    TextField txtUsername;
    
    @FXML
    PasswordField txtPassword;
    
    @FXML
    PasswordField txtRePassword;
    
    @FXML
    Button btnDodaj, btnReset, btnNazad, btnLogout, btnEvidencija, btnKorisnici, btnPostavke;
    
    @FXML
    Label lblErrors;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
       txtUsername.setText(String.valueOf(LoginService.getUser().getUsername()));
       txtPassword.setText(String.valueOf(LoginService.getUser().getPassword()));
       txtRePassword.setText(String.valueOf(LoginService.getUser().getPassword()));
    }    
  
    
    public void btnResetOnClick(){
       txtUsername.setText(String.valueOf(LoginService.getUser().getUsername()));
       txtPassword.setText(String.valueOf(LoginService.getUser().getPassword()));
       txtRePassword.setText(String.valueOf(LoginService.getUser().getPassword()));
    }
    
    
    public void btnEvidencijaOnClick(){
        diplomskievidencijaradnogvremena.DiplomskiEvidencijaRadnogVremena.openWindow("Povijest radnog vremena", btnLogout.getParent(), "UserPregledRadnogVremena");
    }
    public void btnKorisniciOnClick(){
       diplomskievidencijaradnogvremena.DiplomskiEvidencijaRadnogVremena.openWindow("Početna", btnLogout.getParent(), "UserDashboard");
    }
    public void btnPostavkeOnClick(){
        diplomskievidencijaradnogvremena.DiplomskiEvidencijaRadnogVremena.openWindow("Postavke", btnLogout.getParent(), "UserProfil");
    }
    public void btnLogoutOnClick(){
        LoginService.logout(btnLogout.getParent());
    }
    
    public void btnDodajOnClick(){
        if(!txtUsername.getText().equals("")){
            if(!txtPassword.getText().equals("")){
                if(!txtRePassword.getText().equals("")){
                   if(txtPassword.getText().equals(txtRePassword.getText())){
                       User user = new User(txtUsername.getText(), txtPassword.getText(), LoginService.getUser().getRole());
                       user.setID(LoginService.getUser().getID());
                       user.update();
                       LoginService.setUser(user);
                       
                       lblErrors.setTextFill(Color.GREEN);
                       lblErrors.setText(String.valueOf("Izmjene uspješno spremljene!"));
                   }
                   else{
                       lblErrors.setTextFill(Color.RED);
                       lblErrors.setText(String.valueOf("Lozinke se ne podudaraju!"));
                   }
                }
                else{
                    lblErrors.setTextFill(Color.RED);
                    lblErrors.setText(String.valueOf("Ponovite lozinku!"));
                }
            }
            else{
                lblErrors.setTextFill(Color.RED);
                lblErrors.setText(String.valueOf("Unesite lozinku!"));
            }
        }
        else{
            lblErrors.setTextFill(Color.RED);
            lblErrors.setText(String.valueOf("Unesite korisničko ime!"));
        }
    }
}
