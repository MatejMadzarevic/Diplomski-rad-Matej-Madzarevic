
package diplomskievidencijaradnogvremena.controllers;

import diplomskievidencijaradnogvremena.models.User;
import diplomskievidencijaradnogvremena.services.EditDataService;
import diplomskievidencijaradnogvremena.services.LoginService;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.paint.Color;


public class AdminIzmjeniKorisnikaController implements Initializable {
User user = EditDataService.user;

 @FXML
    ComboBox cmbRole;
    
    @FXML
    Button btnDodaj, btnEvidencija, btnKorisnici, btnPostavke, btnLogout;
    
    @FXML
    Button btnReset;
    
    @FXML
    Button btnNazad;
    
 
    @FXML
    TextField txtUsername;

    
    @FXML
    PasswordField txtPassword;
    
    
    @FXML
    PasswordField txtRePassword;

    @FXML
    Label lblErrors;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        if(user != null){
            txtUsername.setText(user.getUsername());
            txtPassword.setText(user.getPassword());
            txtRePassword.setText(user.getPassword());
        }
        ArrayList<String> roles = new ArrayList<>();
        roles.add("user");
        roles.add("admin");
        cmbRole.setItems(FXCollections.observableArrayList(roles));
        
        cmbRole.getSelectionModel().select(user.getRole());
    }   
    
    
    public void setErroText(String txt){
        lblErrors.setTextFill(Color.RED);
        lblErrors.setText(txt);
    }
    
    public void setSuccessText(String txt){
        lblErrors.setTextFill(Color.GREEN);
        lblErrors.setText(txt);
    }
    
        
    public void btnEvidencijaOnClick(){
        diplomskievidencijaradnogvremena.DiplomskiEvidencijaRadnogVremena.openWindow("Pregled radnih vremena", btnDodaj.getParent(), "AdminPregledRadnihVremena");
    }
    public void btnKorisniciOnClick(){
       diplomskievidencijaradnogvremena.DiplomskiEvidencijaRadnogVremena.openWindow("Pregled korisnika", btnDodaj.getParent(), "AdminPregledKorisnika");
    }

    public void btnLogoutOnClick(){
        LoginService.logout(btnDodaj.getParent());
    }

    
    
    public void btnDodajOnClick(){
        String username = txtUsername.getText();
        String password = String.valueOf(txtPassword.getText());
        String rePassword = String.valueOf(txtRePassword.getText());
        if(!username.equals("")){
            if(!password.equals("")){
                if(!rePassword.equals("")){
                    if(password.equals(rePassword)){
                        User user = new User(username, password, cmbRole.getSelectionModel().getSelectedItem().toString());
                        user.setID(EditDataService.user.getID());
                        user.update();

                        setSuccessText("Izmjene uspješno spremljene!");
                    }
                    else{
                        setErroText("Passwordi se ne podudaraju!");
                    }
                }
                else{
                    setErroText("Ponovite password!");
                }
            }
            else{
                setErroText("Unesite password!");
            }
        }
        else{
            setErroText("Unesite korisničko ime!");
        }
            
    }
    
    public void btnResetOnClick(){
        txtUsername.setText("");
        txtPassword.setText("");
        txtRePassword.setText("");
    }
        
  
    
}
