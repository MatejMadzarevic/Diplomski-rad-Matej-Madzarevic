/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package diplomskievidencijaradnogvremena.services;

import diplomskievidencijaradnogvremena.models.User;
import javafx.scene.Parent;

/**
 *
 * @author owner
 */
public class LoginService {
    public static User user;
    public static User getUser(){ return user; }
    public static void setUser(User u){ user = u; }
    
    public static void logout(Parent parent) {
        setUser(null);
        diplomskievidencijaradnogvremena.DiplomskiEvidencijaRadnogVremena.openWindow("Prijava", parent, "Login");
    }
}
